package JavaProject;

import java.util.*;
import java.io.*;
public class Doctor extends Person{
    String speciality;

    Doctor(int id, String name, String speciality){
        super(id, name);
        this.speciality = speciality;
    }

    public String getSpeciality(){
        return speciality;
    }

    public void setSpeciality(String speciality){
        this.speciality = speciality;
    }

    public void saveToFile(){
        File file = new File("doctor.txt");

        try (Scanner scanner = new Scanner(file)) {
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                String[] parts = line.split(",");
                int existingDoctorId = Integer.parseInt(parts[0]);

                if (existingDoctorId == super.getId()) {
                    System.out.println("A doctor with this ID already exists. Doctor not saved.");
                    return;
                }
            }
        } catch (FileNotFoundException e) {
            System.out.println("Doctor file not found. Creating a new one.");
        } catch (IOException e) {
            System.out.println("Error reading doctor file: " + e.getMessage());
        }

        // If no duplicate doctor ID is found, save the doctor
        try (FileWriter writer = new FileWriter(file, true)) {
            writer.write(super.getId() + "," + super.getName() + "," + speciality + "\n");
            System.out.println("\nSuccessfully added Doctor information!!!!!!!!");
        } catch (IOException e) {
            System.out.println("Error saving doctor to file: " + e.getMessage());
        }
    }

    public void updateInFile(Doctor updateDoctor){
        File file = new File("doctor.txt");
        StringBuilder data = new StringBuilder();

        try(Scanner scanner = new Scanner(file)){
            while(scanner.hasNextLine()){
                String line = scanner.nextLine();
                String[] parts = line.split(",");
                int doctorId = Integer.parseInt(parts[0]);

                if(doctorId == updateDoctor.getId()){
                    data.append(updateDoctor.getId()).append(",").append(updateDoctor.getName()).append(",")
                            .append(updateDoctor.getSpeciality()).append("\n");
                }
                else{
                    data.append(line).append("\n");
                }
            }
        }catch(IOException e){
            System.out.println("Error reading doctor file");
        }

        try(FileWriter writer = new FileWriter(file)){
            writer.write(data.toString());
        }catch(IOException e){
            System.out.println("Error updating doctor file");
        }
    }

    public void deleteFromFile(int doctorId){

        File file = new File("doctor.txt");
        StringBuilder data = new StringBuilder();

        try(Scanner scanner = new Scanner(file)){
            while(scanner.hasNextLine()){
                String line = scanner.nextLine();
                String[] parts = line.split(",");
                int id = Integer.parseInt(parts[0]);

                if(doctorId != id){
                    data.append(line).append("\n");
                }
            }
        }catch(IOException e){
            System.out.println("Error reading doctor file");
        }
        try(BufferedWriter writer = new BufferedWriter(new FileWriter(file))){
            writer.write(data.toString());
        }catch(IOException e){
            System.out.println("Error deleting doctor from file");
        }
        System.out.println("\nSuccessfully deleted Doctor information!!!!!!!!");
    }

    public static Doctor loadById(int doctorId){
        File file = new File("doctor.txt");

        try(Scanner scanner = new Scanner(file)){
            while(scanner.hasNextLine()){
                String line = scanner.nextLine();
                String[] parts = line.split(",");
                int id = Integer.parseInt(parts[0]);

                if(id == doctorId){
                    return new Doctor(id, parts[1], parts[2]);
                }
            }
        }catch(IOException e){
            System.out.println("Error reading doctor file");
        }
        return null;
    }
}
