package JavaProject;

import java.io.*;
import java.util.*;

public class Patient extends Person {
    private int age;
    private String address;

    Patient(int id, String name, int age, String address) {
        super(id, name);
        this.age = age;
        this.address = address;
    }

    public int getAge() {
        return age;
    }

    public String getAddress() {
        return address;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public void saveToFile() {
        if (isPatientIdExists(super.getId())) {
            System.out.println("Patient ID already exists. Record not saved.");
            return;
        }

        try (FileWriter writer = new FileWriter("patient.txt", true)) {
            writer.write(super.getId() + "," + super.getName() + "," + age + "," + address + "\n");
            System.out.println("Patient successfully saved.");
        } catch (IOException e) {
            System.out.println("Error saving patient to file: " + e.getMessage());
        }
    }

    public void updateInFile(Patient updatePatient) {
        File file = new File("patient.txt");
        StringBuilder data = new StringBuilder();
        boolean found = false;

        try (Scanner scanner = new Scanner(file)) {
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                String[] parts = line.split(",");
                int patientId = Integer.parseInt(parts[0]);
                if (patientId == updatePatient.getId()) {
                    data.append(updatePatient.getId()).append(",").append(updatePatient.getName()).append(",")
                            .append(updatePatient.getAge()).append(",").append(updatePatient.getAddress()).append("\n");
                    found = true;
                } else {
                    data.append(line).append("\n");
                }
            }
        } catch (IOException e) {
            System.out.println("Error reading patient file: " + e.getMessage());
            return;
        }

        if (!found) {
            System.out.println("Patient with ID " + updatePatient.getId() + " not found. Update failed.");
            return;
        }

        try (FileWriter writer = new FileWriter("patient.txt")) {
            writer.write(data.toString());
            System.out.println("\nSuccessfully added Patient information!!!!!!!!");
        } catch (IOException e) {
            System.out.println("Error updating patient file: " + e.getMessage());
        }
    }

    public void deleteFromFile(int patientId) {
        File file = new File("patient.txt");
        StringBuilder data = new StringBuilder();
        boolean found = false;

        try (Scanner scanner = new Scanner(file)) {
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                String[] parts = line.split(",");
                int id = Integer.parseInt(parts[0]);
                if (id != patientId) {
                    data.append(line).append("\n");
                } else {
                    found = true;
                }
            }
        } catch (IOException e) {
            System.out.println("Error reading patient file: " + e.getMessage());
            return;
        }

        if (!found) {
            System.out.println("Patient with ID " + patientId + " not found. Deletion failed.");
            return;
        }

        try (FileWriter writer = new FileWriter("patient.txt")) {
            writer.write(data.toString());
            System.out.println("Patient successfully deleted.");
        } catch (IOException e) {
            System.out.println("Error deleting patient from file: " + e.getMessage());
        }
    }

    public static Patient loadById(int patientId) {
        File file = new File("patient.txt");

        try (Scanner scanner = new Scanner(file)) {
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                String[] parts = line.split(",");
                int id = Integer.parseInt(parts[0]);
                if (id == patientId) {
                    return new Patient(id, parts[1], Integer.parseInt(parts[2]), parts[3]);
                }
            }
        } catch (IOException e) {
            System.out.println("Error reading patient file: " + e.getMessage());
        }
        System.out.println("Patient with ID " + patientId + " not found.");
        return null;
    }

    private boolean isPatientIdExists(int patientId) {
        File file = new File("patient.txt");

        try (Scanner scanner = new Scanner(file)) {
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                String[] parts = line.split(",");
                int id = Integer.parseInt(parts[0]);
                if (id == patientId) {
                    return true;
                }
            }
        } catch (IOException e) {
            System.out.println("Error checking patient file: " + e.getMessage());
        }
        return false;
    }
}
