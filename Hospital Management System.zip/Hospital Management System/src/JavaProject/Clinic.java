package JavaProject;

import java.util.*;
import java.io.*;
public class Clinic {
    ArrayList<Doctor> doctors ;
    ArrayList<Patient> patients ;
    ArrayList<Appointment> appointments ;

    Clinic(){
        doctors = new ArrayList<>();
        patients = new ArrayList<>();
        appointments = new ArrayList<>();
        loadDoctorsFromFile();
    }

    public void loadDoctorsFromFile(){
        File file = new File("doctor.txt");

        try(Scanner scanner = new Scanner(file)){
            while(scanner.hasNextLine()){
                String line = scanner.nextLine();
                String[] parts = line.split(",");
                int id = Integer.parseInt(parts[0]);
                String name = parts[1];
                String speciality = parts[2];

                Doctor doctor = new Doctor(id, name, speciality);
                doctors.add(doctor);
            }
        }catch(IOException e){
            System.out.println("Error loading doctors from file");
        }
    }

    public void addDoctor(Doctor doctor){
        doctors.add(doctor);
        doctor.saveToFile();
    }

    public void viewDoctor(){
        File file = new File("doctor.txt");

        try(Scanner scanner = new Scanner(file)){
            while(scanner.hasNextLine()){
                String line = scanner.nextLine();
                String[] parts = line.split(",");
                int id = Integer.parseInt(parts[0]);
                String name = parts[1];
                String specilaity = parts[2];
                System.out.println("ID: " + id + ", Name: " + name +
                        ", Speciality: " + specilaity);
            }
        }catch (IOException e){
            System.out.println("Error displaying doctors");
        }
    }


    public void deleteDoctorFromFile(int id){
        loadDoctorsFromFile();
        for(int i = 0; i < doctors.size(); i++){
            if(doctors.get(i).getId() == id){
                doctors.get(i).deleteFromFile(id);
                break;
            }
        }
    }

    public void updateDoctor(Doctor doctor){
        doctor.updateInFile(doctor);
    }

    public void loadPatientsFromFile(){
        File file = new File("patient.txt");

        try(Scanner scanner = new Scanner(file)){
            while(scanner.hasNextLine()){
                String line = scanner.nextLine();
                String[] parts = line.split(",");
                int id = Integer.parseInt(parts[0]);
                String name = parts[1];
                int age = Integer.parseInt(parts[2]);
                String address = parts[3];

                Patient patient = new Patient(id, name, age, address);
                patients.add(patient);
            }
        }catch(IOException e){
            System.out.println("Error loading patients from file");
        }
    }

    public void addPatient(Patient patient){
        patients.add(patient);
        patient.saveToFile();
    }

    public void viewPatient(){
        File file = new File("patient.txt");

        try(Scanner scanner = new Scanner(file)){
            while(scanner.hasNextLine()){
                String line = scanner.nextLine();
                String[] parts = line.split(",");
                int id = Integer.parseInt(parts[0]);
                String name = parts[1];
                int age = Integer.parseInt(parts[2]);
                String address = parts[3];
                System.out.println("ID: " + id + ", Name: " + name + ", Age: " + age +
                        ", Address: " + address);
            }
        }catch (IOException e){
            System.out.println("Error displaying patients");
        }
    }

    public void deletePatientFromFile(int id){
        loadPatientsFromFile();
        for(int i = 0; i < patients.size(); i++){
            if(patients.get(i).getId() == id){
                patients.get(i).deleteFromFile(id);
                break;
            }
        }
    }

    public void updatePatient(Patient patient){
        patient.updateInFile(patient);
    }

    public void loadAppointmentsFromFile(){
        File file = new File("appointment.txt");

        try(Scanner scanner = new Scanner(file)){
            while(scanner.hasNextLine()){
                String line = scanner.nextLine();
                String[] parts = line.split(",");
                int id = Integer.parseInt(parts[0]);
                int doctorId = Integer.parseInt(parts[1]);
                int patientId = Integer.parseInt(parts[2]);
                String date = parts[3];

                Doctor doctor = Doctor.loadById(doctorId);
                Patient patient = Patient.loadById(patientId);

                if(doctor != null && patient != null){
                    Appointment appointment = new Appointment(id, doctor, patient, date);
                    appointments.add(appointment);
                }
                else{
                    System.out.println("Error: doctor and patient not found for appointment id : "+ id);
                }
            }
        }catch(IOException e){
            System.out.println("Error loading appointment from file");
        }
    }

    public void scheduleAppointment(Appointment appointment){
        appointments.add(appointment);
        appointment.saveToFile();
    }

    public void viewAppointment(){
        File file = new File("appointment.txt");

        try(Scanner scanner = new Scanner(file)){
            while(scanner.hasNextLine()){
                String line = scanner.nextLine();
                String[] parts = line.split(",");
                int id = Integer.parseInt(parts[0]);
                Doctor doctor = Doctor.loadById(Integer.parseInt(parts[1]));
                Patient patient = Patient.loadById(Integer.parseInt(parts[2]));
                String date = parts[3];
                System.out.println("ID: " + id + ", Doctor: " + doctor.getName() + ", Patient: " + patient.getName() +
                        ", Date: " + date);
            }
        }catch (IOException e){
            System.out.println("Error displaying appointments");
        }
    }

    public void updateAppointment(Appointment appointment){
        appointment.updateInFile(appointment);
    }

    public void deleteAppointment(int id){
        loadAppointmentsFromFile();
        for(int i = 0; i < appointments.size(); i++){
            if(appointments.get(i).getId() == id){
                appointments.get(i).deleteFromFile(id);
                break;
            }
        }
    }
}
