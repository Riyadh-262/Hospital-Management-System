package JavaProject;

import java.util.*;
import java.io.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

public class Appointment {
    private int id;
    private Doctor doctor;
    private Patient patient;
    private String date;

    private static final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");

    Appointment(int id, Doctor doctor, Patient patient, String date) {
        this.id = id;
        this.doctor = doctor;
        this.patient = patient;
        this.date = date;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Doctor getDoctor() {
        return doctor;
    }

    public void setDoctor(Doctor doctor) {
        this.doctor = doctor;
    }

    public Patient getPatient() {
        return patient;
    }

    public void setPatient(Patient patient) {
        this.patient = patient;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    private boolean isValidDate(String appointmentDate) {
        try {
            LocalDateTime appointmentDateTime = LocalDateTime.parse(appointmentDate, formatter);
            LocalDateTime now = LocalDateTime.now();

            if (appointmentDateTime.isBefore(now)) {
                System.out.println("Appointment date cannot be in the past.");
                return false;
            }
            return true;
        } catch (DateTimeParseException e) {
            System.out.println("Invalid date format. Please use 'yyyy-MM-dd HH:mm'.");
            return false;
        }
    }

    public void saveToFile() {
        if (!isValidDate(date)) {
            return;
        }

        if (isAppointmentIdExists(id)) {
            System.out.println("An appointment with this ID already exists. Appointment not saved.");
            return;
        }

        try (FileWriter writer = new FileWriter("appointment.txt", true)) {
            writer.write(id + "," + doctor.getId() + "," + patient.getId() + "," + date + "\n");
            System.out.println("Appointment successfully saved.");
        } catch (IOException e) {
            System.out.println("Error saving appointment to file: " + e.getMessage());
        }
    }

    private boolean isAppointmentIdExists(int appointmentId) {
        File file = new File("appointment.txt");

        try (Scanner scanner = new Scanner(file)) {
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                String[] parts = line.split(",");
                int id = Integer.parseInt(parts[0]);

                if (id == appointmentId) {
                    return true;
                }
            }
        } catch (IOException e) {
            System.out.println("Error checking appointment file: " + e.getMessage());
        }
        return false;
    }

    public void updateInFile(Appointment updateAppointment) {
        if (!isValidDate(updateAppointment.getDate())) {
            return;
        }

        File file = new File("appointment.txt");
        StringBuilder data = new StringBuilder();

        try (Scanner scanner = new Scanner(file)) {
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                String[] parts = line.split(",");
                int id = Integer.parseInt(parts[0]);

                if (id == updateAppointment.getId()) {
                    data.append(updateAppointment.getId()).append(",")
                            .append(updateAppointment.getDoctor().getId()).append(",")
                            .append(updateAppointment.getPatient().getId()).append(",")
                            .append(updateAppointment.getDate()).append("\n");
                } else {
                    data.append(line).append("\n");
                }
            }
        } catch (IOException e) {
            System.out.println("Error reading appointment file: " + e.getMessage());
        }

        try (FileWriter writer = new FileWriter(file)) {
            writer.write(data.toString());
            System.out.println("Appointment successfully updated.");
        } catch (IOException e) {
            System.out.println("Error updating appointment file: " + e.getMessage());
        }
    }

    public void deleteFromFile(int appointmentId) {
        File file = new File("appointment.txt");
        StringBuilder data = new StringBuilder();

        try (Scanner scanner = new Scanner(file)) {
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                String[] parts = line.split(",");
                int id = Integer.parseInt(parts[0]);

                if (appointmentId != id) {
                    data.append(line).append("\n");
                }
            }
        } catch (IOException e) {
            System.out.println("Error reading appointment file: " + e.getMessage());
        }

        try (FileWriter writer = new FileWriter(file)) {
            writer.write(data.toString());
            System.out.println("Appointment successfully deleted.");
        } catch (IOException e) {
            System.out.println("Error deleting appointment from file: " + e.getMessage());
        }
    }

    public static Appointment loadById(int appointmentId) {
        File file = new File("appointment.txt");

        try (Scanner scanner = new Scanner(file)) {
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                String[] parts = line.split(",");
                int id = Integer.parseInt(parts[0]);

                if (id == appointmentId) {
                    Doctor doctor = Doctor.loadById(Integer.parseInt(parts[1]));
                    Patient patient = Patient.loadById(Integer.parseInt(parts[2]));
                    return new Appointment(id, doctor, patient, parts[3]);
                }
            }
        } catch (IOException e) {
            System.out.println("Error reading appointment file: " + e.getMessage());
        }
        return null;
    }
}
