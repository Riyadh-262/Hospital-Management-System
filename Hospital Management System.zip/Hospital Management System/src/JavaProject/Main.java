package JavaProject;

import java.util.Scanner;
public class Main {
    static Clinic clinic = new Clinic();
    static Scanner scanner = new Scanner(System.in);
    public static void main(String[] args) {
        while(true){
            System.out.println("\nHospital Management System");
            System.out.println("1. Add Doctor");
            System.out.println("2. Add Patient");
            System.out.println("3. Schedule Appointment");
            System.out.println("4. View Doctors");
            System.out.println("5. View Patients");
            System.out.println("6. View Appointments");
            System.out.println("7. Update Doctor");
            System.out.println("8. Update Patient");
            System.out.println("9. Update Appointment");
            System.out.println("10. Delete Doctor");
            System.out.println("11. Delete Patient");
            System.out.println("12. Delete Appointment");
            System.out.println("13. Exit");
            System.out.println("Choose an option: ");

            int choice = scanner.nextInt();
            scanner.nextLine();

            switch(choice){
                case 1 -> addDoctor();
                case 2 -> addPatient();
                case 3 -> scheduleAppointment();
                case 4 -> viewDoctors();
                case 5 -> viewPatients();
                case 6 -> viewAppointments();
                case 7 -> updateDoctor();
                case 8 -> updatePatient();
                case 9 -> updateAppointment();
                case 10 -> deleteDoctor();
                case 11 -> deletePatient();
                case 12 -> deleteAppointment();
                case 13 -> {
                    System.out.println("Exiting the system........");
                    System.exit(0);
                }
                default -> System.out.println("Invalid choice. Please try again");
            }
        }
    }

    public static void addDoctor(){
        System.out.println("Enter the Doctor ID: ");
        int id = scanner.nextInt();
        scanner.nextLine();
        System.out.println("Enter the Doctor Name: ");
        String name = scanner.nextLine();
        System.out.println("Enter the Doctor Speciality: ");
        String specialty = scanner.nextLine();

        Doctor doctor = new Doctor(id, name, specialty);
        clinic.addDoctor(doctor);

    }

    public static void addPatient(){
        System.out.println("Enter the Patient ID: ");
        int id = scanner.nextInt();
        scanner.nextLine();
        System.out.println("Enter the Patient Name: ");
        String name = scanner.nextLine();
        System.out.println("Enter the Patient Age: ");
        int age = scanner.nextInt();
        scanner.nextLine();
        System.out.println("Enter the Patient Address: ");
        String address = scanner.nextLine();

        Patient patient = new Patient(id, name, age, address);
        clinic.addPatient(patient);

    }

    public static void scheduleAppointment(){
        System.out.println("Enter Appointment ID: ");
        int id = scanner.nextInt();
        scanner.nextLine();
        System.out.println("Enter Doctor ID: ");
        int doctorId = scanner.nextInt();
        scanner.nextLine();
        System.out.println("Enter Patient ID: ");
        int patientId = scanner.nextInt();
        scanner.nextLine();
        System.out.println("Enter Appointment Date (YYYY-MM-DD): ");
        String date = scanner.nextLine();

        Doctor doctor = Doctor.loadById(doctorId);
        Patient patient = Patient.loadById(patientId);

        if(doctor != null && patient != null){
            Appointment apoointment = new Appointment(id, doctor, patient, date);
            clinic.scheduleAppointment(apoointment);

        }
        else{
            System.out.println("Doctor or Patient not found");
        }
    }

    public static void viewDoctors(){
        clinic.viewDoctor();
    }

    public static void viewPatients(){
        clinic.viewPatient();
    }

    public static void viewAppointments(){
        clinic.viewAppointment();
    }

    public static void updateDoctor(){
        System.out.println("Enter the Doctor ID to update: ");
        int id = scanner.nextInt();
        scanner.nextLine();

        Doctor doctor = Doctor.loadById(id);

        if(doctor != null){
            System.out.println("Enter the new Doctor Name: ");
            String name = scanner.nextLine();
            System.out.println("Enter the new Doctor Speciality: ");
            String speciality = scanner.nextLine();

            doctor.setName(name);
            doctor.setSpeciality(speciality);

            clinic.updateDoctor(doctor);

            System.out.println("\nSuccessfully updated Doctor information!!!!!!!!");
        }
        else{
            System.out.println("Doctor not found");
        }
    }

    public static void updatePatient(){
        System.out.println("Enter the Patient ID to update: ");
        int id = scanner.nextInt();
        scanner.nextLine();

        Patient patient = Patient.loadById(id);

        if(patient != null){
            System.out.println("Enter the new Patient Name: ");
            String name = scanner.nextLine();
            System.out.println("Enter the new Patient Age: ");
            int age = scanner.nextInt();
            scanner.nextLine();
            System.out.println("Enter the new Patient Address: ");
            String address = scanner.nextLine();

            patient.setName(name);
            patient.setAge(age);
            patient.setAddress(address);

            clinic.updatePatient(patient);

            System.out.println("\nSuccessfully updated Patient information!!!!!!!!");
        }
        else{
            System.out.println("Patient not found");
        }
    }

    public static void updateAppointment(){
        System.out.println("Enter the Appointment ID to update: ");
        int id = scanner.nextInt();
        scanner.nextLine();

        Appointment appointment = Appointment.loadById(id);

        if(appointment != null){
            System.out.println("Enter the new Doctor ID: ");
            int doctorID = scanner.nextInt();
            scanner.nextLine();
            System.out.println("Enter the new Patient ID: ");
            int patientId = scanner.nextInt();
            scanner.nextLine();
            System.out.println("Enter the new Date (YYYY-MM-DD): ");
            String date = scanner.nextLine();

            Doctor doctor = Doctor.loadById(doctorID);
            Patient patient = Patient.loadById(patientId);

            appointment.setDoctor(doctor);
            appointment.setPatient(patient);
            appointment.setDate(date);

            clinic.updateAppointment(appointment);

            System.out.println("\nSuccessfully updated Appointment information!!!!!!!!");
        }
        else{
            System.out.println("Appointment not found");
        }
    }

    public static void deleteDoctor(){
        System.out.println("Enter the doctor ID to delete: ");
        int id = scanner.nextInt();

        Doctor doctor = Doctor.loadById(id);

        if(doctor != null){
            clinic.deleteDoctorFromFile(id);
        }
        else{
            System.out.println("Doctor ID not found");
        }
    }

    public static void deletePatient(){
        System.out.println("Enter the patient ID to delete: ");
        int id = scanner.nextInt();

        Patient patient = Patient.loadById(id);

        if(patient != null){
            clinic.deletePatientFromFile(id);
            System.out.println("\nSuccessfully deleted Patient information!!!!!!!!");
        }
        else{
            System.out.println("Patient ID not found");
        }
    }

    public static void deleteAppointment(){
        System.out.println("Enter the Appointment ID to delete: ");
        int id = scanner.nextInt();

        Appointment appointment = Appointment.loadById(id);

        if(appointment != null){
            clinic.deleteAppointment(id);
            System.out.println("\nSuccessfully deleted Appointment!!!!!!!!");
        }
        else{
            System.out.println("Appointment ID not found");
        }
    }
}

